import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TshirtsComponent } from './tshirts/tshirts.component';
import { TrackPantsComponent } from './track-pants/track-pants.component';
import { ShortsComponent } from './shorts/shorts.component';
import { ShoesComponent } from './shoes/shoes.component';

@NgModule({
  declarations: [
    AppComponent,
    TshirtsComponent,
    TrackPantsComponent,
    ShortsComponent,
    ShoesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
