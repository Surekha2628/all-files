import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-track-pants',
  templateUrl: './track-pants.component.html',
  styleUrls: ['./track-pants.component.css']
})
export class TrackPantsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
