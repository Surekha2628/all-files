import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackPantsComponent } from './track-pants.component';

describe('TrackPantsComponent', () => {
  let component: TrackPantsComponent;
  let fixture: ComponentFixture<TrackPantsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrackPantsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackPantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
