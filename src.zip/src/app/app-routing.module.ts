import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ShoesComponent } from './shoes/shoes.component';
import { ShortsComponent } from './shorts/shorts.component';
import { TshirtsComponent } from './tshirts/tshirts.component';
import { TrackPantsComponent } from './track-pants/track-pants.component';

const routes: Routes = [
  {path:"tshirts",component:TshirtsComponent},
  {path:"track-pants",component:TrackPantsComponent},
  {path:"shorts",component:ShortsComponent},
  {path:"shoes",component:ShoesComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
